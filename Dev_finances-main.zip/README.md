# Dev_finances
Sistema de controle financeiro construido na Maratona nlw.


## :rocket: Technologies

This project was developed at Rocketseat Discover Marathon with the following technologies:

- [HTML5]()
- [CSS3]()
- [JavaScript]()



### :floppy_disk: Installation

```
$ git clone https://github.com/RafaelCasaSanta/Dev_finances.git

$ Install Live Server Extension 
```

### :hammer: How to Use

Run Project 
```
$ [Alt + L + O]
```
